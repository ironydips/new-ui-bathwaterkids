(function(angular) {

'use strict';

angular.module('customersUser',[
	'ui.bootstrap',
	'bathwaterApp.services',
	'customerProfileModal',
	'customerSubscribeModal',
	'customerUserReqModal'
	]);

})(window.angular);