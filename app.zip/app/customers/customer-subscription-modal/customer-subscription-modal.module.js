(function(angular) {
'use strict';

angular.module('customerSubscribeModal',[]);

})(window.angular);