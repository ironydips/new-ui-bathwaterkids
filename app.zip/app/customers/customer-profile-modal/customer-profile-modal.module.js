(function(angular) {
'use strict';

angular.module('customerProfileModal',[
	'bathwaterApp.services',
	'customerSubItemModal'
	]);

})(window.angular);