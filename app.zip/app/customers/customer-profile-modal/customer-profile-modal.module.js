(function(angular) {
'use strict';

angular.module('customerProfileModal',[
	'bathwaterApp.services',
	]);

})(window.angular);