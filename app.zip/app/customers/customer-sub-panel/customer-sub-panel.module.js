(function(angular) {
'use strict';

angular.module('customersSubPanel',[
	'customersUser'
		]);

})(window.angular);