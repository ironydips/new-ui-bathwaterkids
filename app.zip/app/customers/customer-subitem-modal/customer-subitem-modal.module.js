(function(angular) {
'use strict';

angular.module('customerSubItemModal',[
		'ui.bootstrap'
	]);

})(window.angular);