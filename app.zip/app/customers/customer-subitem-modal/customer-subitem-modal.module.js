(function(angular) {
'use strict';

angular.module('customerSubItemModal',[
		'ui.bootstrap',
		'bootstrapLightbox'
	]);

})(window.angular);