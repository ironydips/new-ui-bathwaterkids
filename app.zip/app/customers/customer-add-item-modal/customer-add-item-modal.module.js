(function(angular) {
'use strict';

angular.module('customerAddItemModal',[
		'bathwaterApp.services',
		'customerSubItemModal',
		'updateCreditModal'
	]);

})(window.angular);