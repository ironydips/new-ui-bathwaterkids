(function(angular) {
'use strict';

angular.module('customerUserReqModal',[
	'bathwaterApp.services',
	'bootstrapLightbox',
	'customerSubItemModal',
	'customerAddItemModal',
	'updateCreditModal'
	]);

})(window.angular);