(function (angular) {
	angular.config = {
		baseUrl: "https://production.bathwaterkids.com",
		clientID: "532068338146-cgtbu6ipvaj6clem5kf021u8maj8jm02.apps.googleusercontent.com"
	}
})(window.angular)