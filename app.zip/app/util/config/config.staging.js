(function (angular) {
	angular.config = {
		baseUrl: "https://staging.bathwaterkids.com",
		clientID: "531188035829-e83na2d4nj50fu7baqc7q7mlqauboqvs.apps.googleusercontent.com"
	}
})(window.angular)
