(function (angular) {
	angular.config = {
		baseUrl: "http://bathwater-staging.us-east-1.elasticbeanstalk.com",
		clientID: "531188035829-e83na2d4nj50fu7baqc7q7mlqauboqvs.apps.googleusercontent.com"
	}
})(window.angular)
