(function(angular) {
'use strict';

angular.module('updateCreditModal',['bathwaterApp.services']);

})(window.angular);