(function(angular){
	'use strict';
	angular.module("inventoryIncomingDetails",[
			'ui.bootstrap',
			'bathwaterApp.services',
			'bootstrapLightbox',
			'updateCreditModal',
			'deleteConfirmationModal',
			'customerSubItemModal'
		]);

})(window.angular);