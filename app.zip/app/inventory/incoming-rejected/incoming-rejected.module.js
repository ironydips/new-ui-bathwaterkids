(function(angular){
	'use strict';
	angular.module("inventoryRejectedDetails",[
			'ui.bootstrap',
			'bathwaterApp.services',
			'bootstrapLightbox',
			'updateCreditModal',
			'customerSubItemModal'
		]);

})(window.angular);