(function(angular) {
'use strict';

angular.module('deleteConfirmationModal',[
		'bathwaterApp.services'
	]);

})(window.angular);