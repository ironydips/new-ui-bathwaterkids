(function(angular){
	'use strict';
	angular.module("inventoryStoredRecordsDetails",[
			'ui.bootstrap',
			'bathwaterApp.services',
			'bootstrapLightbox',
			'updateCreditModal'
		]);

})(window.angular);