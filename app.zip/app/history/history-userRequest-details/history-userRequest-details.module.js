(function(angular){
	'use strict';
	angular.module("historyUserReqDetails",[
			'ui.bootstrap',
			'angularMoment',
			'bathwaterApp.services',
			'bootstrapLightbox',
			'updateCreditModal',
			'viewUserDetailModal',
			'viewItemDetailModal'
		]);

})(window.angular);