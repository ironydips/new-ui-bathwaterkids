'use strict';

angular.module('historySubPanel',[]);