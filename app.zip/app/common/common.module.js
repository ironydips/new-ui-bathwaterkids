(function (angular) {
	"use strict";

	angular.module('bathwaterApp.common',[]);
})(window.angular)