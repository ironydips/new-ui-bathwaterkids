(function(angular) {

'use strict';

angular.module('adminSubPanel',[]);

})(window.angular);