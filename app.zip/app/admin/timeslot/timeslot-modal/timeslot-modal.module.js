(function(){
'use strict';

angular.module('timeslotModal',[
		'720kb.datepicker',
		'bathwaterApp.services'
	]);

})(window.angular)