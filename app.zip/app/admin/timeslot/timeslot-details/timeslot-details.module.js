'use strict';

angular.module('timeslotDetails',[
		'ui.bootstrap',
		'bathwaterApp.services',
	    'timeslotModal',
	    'timeslotShowAllModal',
	    'editDeleteTSModal',
	    'timeslotResetModal'
	]);