(function(){
'use strict';

angular.module('timeslotResetModal',[
		'720kb.datepicker',
		'bathwaterApp.services'
	]);

})(window.angular)