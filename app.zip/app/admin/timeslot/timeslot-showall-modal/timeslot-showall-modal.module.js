'use strict';


angular.module('timeslotShowAllModal',[
		'bathwaterApp.services',
	]);