(function(angular) {
'use strict';

angular.module('driverModal',[
	'bathwaterApp.services',
	]);

})(window.angular);