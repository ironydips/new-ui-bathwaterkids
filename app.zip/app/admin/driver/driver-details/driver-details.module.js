(function(angular) {
'use strict';

angular.module('driverDetails',[
	'ui.bootstrap',
	'bathwaterApp.services',
	'driverModal'
		]);

})(window.angular);