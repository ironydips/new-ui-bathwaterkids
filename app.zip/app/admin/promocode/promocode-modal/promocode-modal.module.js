'use strict';

angular.module('promoModal',[
	 'bathwaterApp.services',
	]);

