(function(angular) {

'use strict';

angular.module("promocodeDetails",[
	'ui.bootstrap',
	'bathwaterApp.services',
	'promoModal'
	]);

})(window.angular);