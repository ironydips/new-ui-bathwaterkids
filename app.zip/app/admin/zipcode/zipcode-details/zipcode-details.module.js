(function(angular) {
'use strict';

angular.module('zipcodeDetails',[
	'ui.bootstrap',
	'bathwaterApp.services',
	'zipModal'
	]);

})(window.angular);