(function(angular) {
'use strict';

angular.module('zipModal',[
	'bathwaterApp.services',
	]);

})(window.angular);