(function(angular) {

'use strict';

angular.module('adminPanel',[
	'bathwaterApp.common'
	]);

})(window.angular);