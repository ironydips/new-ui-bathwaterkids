(function(angular) {
'use strict';

angular.module('truckDetails',[
	'truckModal',
	'images-resizer',
	'ui.bootstrap',
	'bathwaterApp.services',
	]);

})(window.angular);