(function(angular) {
'use strict';

angular.module('adminLayout',[]);

})(window.angular);
