(function(angular) {
	"use strict";
	
	angular.module('bathwaterApp.services',[
			'bathwaterApp.common'
		]);	

})(window.angular);