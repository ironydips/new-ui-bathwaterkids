(function(angular) {
'use strict';

angular.module('userRequestInProgressModal',[
		'bathwaterApp.services'
	]);

})(window.angular);