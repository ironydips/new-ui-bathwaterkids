(function(angular) {
'use strict';

angular.module('userRequestNotStartedModal',[
		'assignDriverModal',
		'ui.bootstrap',
		'bathwaterApp.services'
	]);

})(window.angular);