(function(angular) {
'use strict';

angular.module('userRequestPickUpModal',[
		'bathwaterApp.services'
	]);

})(window.angular);