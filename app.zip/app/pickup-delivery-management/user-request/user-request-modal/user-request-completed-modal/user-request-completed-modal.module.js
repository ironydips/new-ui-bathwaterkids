(function(angular) {
'use strict';

angular.module('userRequestCompleteModal',[
		'bathwaterApp.services'
	]);

})(window.angular);