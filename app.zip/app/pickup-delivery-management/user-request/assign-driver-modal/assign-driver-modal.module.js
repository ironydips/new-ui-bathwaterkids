'use strict';

angular.module('assignDriverModal',['bathwaterApp.services',]);

