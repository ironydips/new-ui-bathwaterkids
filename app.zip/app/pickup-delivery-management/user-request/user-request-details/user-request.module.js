(function(angular) {
'use strict';

angular.module('userRequest',[
	'ui.bootstrap',
	'bathwaterApp.services',
	'userRequestCompleteModal',
	'userRequestNotStartedModal',
	'userRequestInProgressModal'
	]);

})(window.angular);