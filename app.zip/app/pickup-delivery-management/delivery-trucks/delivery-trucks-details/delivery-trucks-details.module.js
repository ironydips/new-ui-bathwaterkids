(function(angular){
	'use strict';
	angular.module("deliveryTrucks",[
	'ui.bootstrap',
	'deliverytruckModal',
	'historyModal'
		]);

})(window.angular);