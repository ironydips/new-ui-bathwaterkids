(function(angular) {
'use strict';

angular.module('historyModal',[
		'bathwaterApp.services'
	]);

})(window.angular);