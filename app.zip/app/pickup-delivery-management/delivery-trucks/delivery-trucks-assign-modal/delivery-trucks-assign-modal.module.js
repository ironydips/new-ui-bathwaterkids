(function(angular) {
'use strict';

angular.module('deliverytruckModal',[
		'bathwaterApp.services'
	]);

})(window.angular);