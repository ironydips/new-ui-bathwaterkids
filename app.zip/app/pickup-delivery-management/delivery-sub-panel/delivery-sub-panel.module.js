'use strict';

angular.module('deliverySubPanel',[]);