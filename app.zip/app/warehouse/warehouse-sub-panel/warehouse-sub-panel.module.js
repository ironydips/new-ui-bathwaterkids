'use strict';

angular.module('warehouseSubPanel',[]);