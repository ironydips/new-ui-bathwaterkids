'use strict';


angular.module('outgoingAssignTruckModal',['ngToast','bathwaterApp.services']);