(function(){
'use strict';

angular.module('outboundProductModal',[
		'moreDetailsModal',
		'bathwaterApp.services'
	]);

})(window.angular)