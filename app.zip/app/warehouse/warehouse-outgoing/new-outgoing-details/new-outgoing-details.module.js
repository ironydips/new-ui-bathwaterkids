'use strict';

angular.module('newOutgoingWarehouseDetails',[
		'ui.bootstrap',
	    'moreDetailsModal',
	    'outgoingAssignTruckModal',
	    'outboundProductModal',
	    'bathwaterApp.services',
	    'bootstrapLightbox'
	]);