'use strict';


angular.module('processItemsModal',[]);