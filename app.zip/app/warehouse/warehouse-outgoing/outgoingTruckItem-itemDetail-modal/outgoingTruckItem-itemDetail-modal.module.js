(function(angular) {
'use strict';

angular.module('viewOutgoingTruckItemModal',[
	'bathwaterApp.services',
	'bootstrapLightbox',
	'viewUserDetailModal'
	]);

})(window.angular);