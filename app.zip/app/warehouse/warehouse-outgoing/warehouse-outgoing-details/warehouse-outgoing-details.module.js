'use strict';

angular.module('outgoingWarehouseDetails',[
		'ui.bootstrap',
	    'processItemsModal',
	   
	]);