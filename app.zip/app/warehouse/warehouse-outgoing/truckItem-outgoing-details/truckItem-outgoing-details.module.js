(function(angular) {
'use strict';

angular.module('truckItemOutgoingWarehouseDetails',[
		'ui.bootstrap',
		'720kb.datepicker',
		'angularMoment',
		'viewOutgoingTruckItemModal',
	    'driverInfoModal',
	    'bathwaterApp.services'
	]);

})(window.angular);