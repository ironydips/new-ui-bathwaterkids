'use strict';

angular.module('driverInfoModal',[]);

