(function(angular) {
'use strict';

angular.module('moreDetailsModal',['bootstrapLightbox']);

})(window.angular);