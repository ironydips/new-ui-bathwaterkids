(function(){
'use strict';

angular.module('receiveincomingProductModal',[
		'updateLocStoredModal',
		'moreDetailsModal',
		'bathwaterApp.services'
	]);

})(window.angular)