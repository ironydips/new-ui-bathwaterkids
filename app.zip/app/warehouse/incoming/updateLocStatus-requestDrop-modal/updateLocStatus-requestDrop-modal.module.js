'use strict';

angular.module('updateLocRequestDropModal',['bathwaterApp.services',]);

