'use strict';


angular.module('mergeincomingShowAllModal',[
	'ngToast','bathwaterApp.services', 'bootstrapLightbox'
	]);