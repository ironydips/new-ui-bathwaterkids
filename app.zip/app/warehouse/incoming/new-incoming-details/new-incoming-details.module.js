'use strict';

angular.module('newIncomingWarehouseDetails',[
		'ui.bootstrap',
	    'moreDetailsModal',
	    'updateLocStatusModal',
	    'bathwaterApp.services',
	    'bootstrapLightbox'
	]);