(function(){
'use strict';

angular.module('storedProductModal',[
		'moreDetailsModal',
		'ngToast',
		'updateCreditStoredModal',
		'bathwaterApp.services'
	]);

})(window.angular)