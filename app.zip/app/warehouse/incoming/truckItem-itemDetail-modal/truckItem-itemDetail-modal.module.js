(function(angular) {
'use strict';

angular.module('viewTruckItemModal',[
	'bathwaterApp.services',
	'bootstrapLightbox',
	'viewUserDetailModal'
	]);

})(window.angular);