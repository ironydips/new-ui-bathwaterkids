(function(angular) {
'use strict';

angular.module('mergedIncomingWarehouseDetails',[
		'ui.bootstrap',
		'720kb.datepicker',
		'mergeincomingShowAllModal',
	    'receiveincomingProductModal',
	    'storedProductModal',
	    'bathwaterApp.services'
	]);

})(window.angular);