(function(angular) {
'use strict';

angular.module('viewUserDetailModal',[]);

})(window.angular);