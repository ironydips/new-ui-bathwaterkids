'use strict';

angular.module('incomingWarehouseDetails',[
		'ui.bootstrap',
	    'addInventoryModal',
	    'incomingShowAllModal',
	    'bathwaterApp.services'
	]);