'use strict';

angular.module('updateLocStatusModal',['bathwaterApp.services',]);

