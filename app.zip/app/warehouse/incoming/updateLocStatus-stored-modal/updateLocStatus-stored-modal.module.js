'use strict';

angular.module('updateLocStoredModal',['ngToast','bathwaterApp.services',]);

