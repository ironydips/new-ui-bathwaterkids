'use strict';


angular.module('incomingShowAllModal',['bathwaterApp.services']);