(function(angular) {
'use strict';

angular.module('truckItemIncomingWarehouseDetails',[
		'ui.bootstrap',
		'720kb.datepicker',
		'angularMoment',
		'viewTruckItemModal',
	    'receiveincomingProductModal',
	    'storedProductModal',
	    'bathwaterApp.services'
	]);

})(window.angular);