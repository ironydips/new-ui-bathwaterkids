'use strict';

angular.module('updateCreditStoredModal',[
	'bathwaterApp.services'
]);

