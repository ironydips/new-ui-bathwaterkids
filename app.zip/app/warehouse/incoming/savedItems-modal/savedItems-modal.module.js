(function(){
'use strict';

angular.module('addInventoryModal',[
		'bathwaterApp.services'
	]);

})(window.angular)