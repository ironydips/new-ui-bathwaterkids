(function(angular) {


angular.module('manageAdmin',[
	'ui.bootstrap',
	'bathwaterApp.services',
	'addAdminModal',
	'deleteAdminModal'
	]);

})(window.angular);