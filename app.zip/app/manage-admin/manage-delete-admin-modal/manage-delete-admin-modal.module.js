(function(angular) {
'use strict';

angular.module('deleteAdminModal',[
		'bathwaterApp.services'
	]);

})(window.angular);