(function(angular) {
'use strict';

angular.module('addAdminModal',[
	'bathwaterApp.services'
	]);

})(window.angular);