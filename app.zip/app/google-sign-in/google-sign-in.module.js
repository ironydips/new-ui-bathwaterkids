'use strict';

angular.module('googleSignIn',[
	'bathwaterApp.common',
	'bathwaterApp.services'
	]);