'use strict';

angular.module('googleSignIn',[
	'ngCookies',
	'bathwaterApp.common',
	'bathwaterApp.services'
	]);