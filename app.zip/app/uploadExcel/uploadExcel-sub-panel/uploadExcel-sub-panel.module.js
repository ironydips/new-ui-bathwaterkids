'use strict';

angular.module('uploadExcelSubPanel',[]);