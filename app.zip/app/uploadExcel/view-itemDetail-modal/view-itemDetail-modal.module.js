(function(angular) {
'use strict';

angular.module('viewItemDetailModal',['bathwaterApp.services','customerSubItemModal']);

})(window.angular);