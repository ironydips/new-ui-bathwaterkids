(function(angular) {
'use strict';

	angular.module('index',[]);

})(window.angular);