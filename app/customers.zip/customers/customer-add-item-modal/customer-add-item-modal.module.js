(function(angular) {
'use strict';

angular.module('customerAddItemModal',[
		'bathwaterApp.services',
		'customerSubItemModal'
	]);

})(window.angular);