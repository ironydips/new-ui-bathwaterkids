(function(angular) {
'use strict';

angular.module('editDeleteTSModal',[
	'bathwaterApp.services',
	]);

})(window.angular);