'use strict';

angular.module('inventorySubPanel',[]);