(function(angular) {
'use strict';

angular.module('truckModal',[
		'bathwaterApp.services',
	]);

})(window.angular);